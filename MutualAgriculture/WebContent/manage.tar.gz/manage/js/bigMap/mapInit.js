/**
 * Created by Administrator on 2016/10/5.
 */
// 百度地图API功能
var map = new BMap.Map("allmap");

map.enableScrollWheelZoom(true);  //开启鼠标滚轮缩放

var point = new BMap.Point(112.552478,26.923761);
map.centerAndZoom(point,14);

//定位跳转到当地地图





